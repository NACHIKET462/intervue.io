package com.demo.Utils;

public class Constants {
    public static final String BASE_URL = "https://www.intervue.io/";
    public static final String LOGIN_URL = "https://www.intervue.io/access-account";
    public static final String USER_EMAIL = "nachikchita@gmail.com";
    public static final String USER_PASSWORD = "asdfghrty";
    public static final String USER_EMAIL2 = "test@example.com";
    public static final String USER_PASSWORD2 = "12345678";
}
