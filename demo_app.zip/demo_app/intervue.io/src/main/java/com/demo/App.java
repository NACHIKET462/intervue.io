package com.demo;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.demo.Pages.Login;
import com.demo.Utils.Constants;
import com.demo.Utils.ScreenshotUtil;

import java.time.Duration;
import java.util.List;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.manage().window().maximize();
            driver.get(Constants.BASE_URL);
            System.out.println("Page Title: " + driver.getTitle());

            clickElement(wait, By.xpath("//a[contains(@class, 'loginBtn')]"));

            driver.get(Constants.LOGIN_URL);
            System.out.println("Navigated to: " + driver.getCurrentUrl());

            WebElement greenLoginButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//a[contains(@class, 'AccessAccount-ColoredButton')]/div[text()='Login']")));
            clickElementWithJS(driver, greenLoginButton);

            handleNewTab(driver);

            // Call the generic login function
            Login.performLogin(driver, wait, Constants.USER_EMAIL2, Constants.USER_PASSWORD2);

            Thread.sleep(5000);

            ScreenshotUtil.takeFullPageScreenshot(driver, "screenshot.png");
            Thread.sleep(1000);
            
            // Enter valid credentials and log in
            Login.performLogin(driver, wait, Constants.USER_EMAIL, Constants.USER_PASSWORD);

            // Keep the browser open indefinitely
            while (true) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }

    private static void clickElement(WebDriverWait wait, By locator) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        element.click();
        System.out.println("Clicked element: " + locator.toString());
    }

    private static void clickElementWithJS(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element); 
        try {
            Thread.sleep(1000); 
            js.executeScript("arguments[0].click();", element);
            System.out.println("Clicked element using JavaScript.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
    }

    private static void handleNewTab(WebDriver driver) {
        List<String> tabs = List.copyOf(driver.getWindowHandles());
        if (tabs.size() > 1) {
            driver.switchTo().window(tabs.get(1)).close();
            System.out.println("Closed the new tab.");
            driver.switchTo().window(tabs.get(0));
        }
    }

}
