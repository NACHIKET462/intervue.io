package com.demo;



import com.demo.Pages.Login;
import com.demo.Utils.Constants;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class LoginTest {
    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void testValidLogin() {
        driver.get(Constants.LOGIN_URL);
        Login.performLogin(driver, wait, Constants.USER_EMAIL, Constants.USER_PASSWORD);

        // Verify login success (Assuming successful login redirects or shows an element)
        boolean isLoggedIn = driver.findElements(By.xpath("//button[contains(text(),'Logout')]")).size() > 0;
        Assert.assertTrue(isLoggedIn, "Login failed with valid credentials!");
    }

    @Test(priority = 2)
    public void testInvalidLogin() {
        driver.get(Constants.LOGIN_URL);
        Login.performLogin(driver, wait, "invalid@example.com", "wrongpassword");

        // Verify error message appears
        WebElement errorMessage = driver.findElement(By.xpath("//div[contains(@class, 'error-message')]"));
        Assert.assertTrue(errorMessage.isDisplayed(), "Error message not displayed for invalid login!");
    }

    @Test(priority = 3)
    public void testEmptyCredentials() {
        driver.get(Constants.LOGIN_URL);
        Login.performLogin(driver, wait, "", "");

        // Verify validation message appears
        WebElement emailError = driver.findElement(By.id("login_email_error"));
        WebElement passwordError = driver.findElement(By.id("login_password_error"));

        Assert.assertTrue(emailError.isDisplayed(), "Email validation message not displayed!");
        Assert.assertTrue(passwordError.isDisplayed(), "Password validation message not displayed!");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

